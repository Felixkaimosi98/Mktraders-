import { useEffect, useState } from 'react';
import axios from 'axios';

export default function App() {
  const [price, setPrice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastTrade, setLastTrade] = useState(null);
  const symbol = 'R_50';

  useEffect(() => {
    const fetchPrice = async () => {
      try {
        const res = await axios.get(`http://localhost:4000/api/price/${symbol}`);
        setPrice(res.data.price);
      } catch (err) {
        console.error(err);
      }
    };
    fetchPrice();
    const id = setInterval(fetchPrice, 2000);
    return () => clearInterval(id);
  }, []);

  const getProposal = async (contract_type) => {
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:4000/api/proposal', {
        symbol,
        amount: 10,
        contract_type,
        duration: 1,
        duration_unit: 'm',
        currency: 'USD'
      });
      setLoading(false);
      return res.data.proposal;
    } catch (err) {
      setLoading(false);
      alert('Error getting proposal: ' + (err.response?.data?.error || err.message));
      return null;
    }
  };

  const placeTrade = async (contract_type) => {
    const proposal = await getProposal(contract_type);
    if (!proposal) return;
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:4000/api/buy', {
        symbol,
        amount: 10,
        contract_type,
        duration: 1,
        duration_unit: 'm',
        currency: 'USD'
      });
      setLoading(false);
      if (res.data.success) {
        setLastTrade(res.data.buy);
        alert('Trade placed! Contract ID: ' + res.data.buy.contract_id);
      } else {
        alert('Buy failed: ' + JSON.stringify(res.data));
      }
    } catch (err) {
      setLoading(false);
      alert('Error placing buy: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-6">
      <header className="flex justify-between w-full max-w-3xl bg-white p-4 rounded-2xl shadow">
        <h1 className="text-xl font-bold text-gray-700">Deriv Binary Trading (LIVE)</h1>
        <button className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">Login with Deriv</button>
      </header>

      <div className="mt-10 bg-white rounded-2xl shadow p-6 w-80 text-center">
        <h2 className="text-lg font-semibold mb-2">{symbol}</h2>
        <p className="text-3xl font-bold text-blue-600">{price ? price : 'Loading...'}</p>
      </div>

      <div className="mt-6 bg-white rounded-2xl shadow p-6 flex flex-col items-center">
        <h3 className="text-lg font-semibold mb-4">Trade Controls</h3>
        <div className="flex gap-4">
          <button onClick={() => placeTrade('CALL')} className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">
            Buy ↑
          </button>
          <button onClick={() => placeTrade('PUT')} className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600">
            Sell ↓
          </button>
        </div>
        {loading && <p className="mt-4">Processing…</p>}
        {lastTrade && (
          <div className="mt-4 text-sm text-left w-full max-w-md">
            <strong>Last trade:</strong>
            <pre className="bg-gray-100 p-2 rounded">{JSON.stringify(lastTrade, null, 2)}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
