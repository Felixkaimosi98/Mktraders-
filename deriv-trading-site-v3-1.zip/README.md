# Deriv Trading Site v3 (Live)

This version connects to Deriv's live WebSocket API for `proposal` and `buy` calls.
**WARNING:** This will place real trades if you provide valid credentials and run the backend.

## Setup

1. Backend
   - cd backend
   - cp .env.example .env
   - Edit `.env` and set DERIV_APP_ID and DERIV_API_TOKEN (your Deriv API token).
   - npm install
   - npm start

2. Frontend
   - cd frontend
   - npm install
   - npm run dev

3. Open http://localhost:5173 and use the UI to fetch proposals and place buys.
- Check your Deriv account statements for actual trades.

## Security & compliance notes
- Keep your DERIV_API_TOKEN secret. Never commit it to source control.
- Only use real trading with accounts you control and funds you can afford.
- Ensure you comply with local laws and Deriv's terms of service.
