import express from "express";
import WebSocket from "ws";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const APP_ID = process.env.DERIV_APP_ID || "1089";
const TOKEN = process.env.DERIV_API_TOKEN || null;

// Helper to create a websocket connection to Deriv
function createDerivSocket() {
  // use official endpoint;
  return new WebSocket(`wss://ws.derivws.com/websockets/v3?app_id=${APP_ID}`);
}

// Price endpoint (live tick)
app.get("/api/price/:symbol", async (req, res) => {
  const symbol = req.params.symbol;
  const ws = createDerivSocket();
  let responded = false;

  ws.on("open", () => {
    ws.send(JSON.stringify({ ticks: symbol }));
  });

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.tick && !responded) {
        responded = true;
        res.json({ symbol, price: data.tick.quote });
        ws.close();
      } else if (data.error && !responded) {
        responded = true;
        res.status(502).json({ error: data.error.message });
        ws.close();
      }
    } catch (err) {
      if (!responded) {
        responded = true;
        res.status(500).json({ error: "invalid response from websocket" });
      }
      ws.close();
    }
  });

  ws.on("error", (err) => {
    if (!responded) {
      responded = true;
      res.status(500).json({ error: "websocket error" });
    }
  });

  setTimeout(() => {
    if (!responded) {
      responded = true;
      try { ws.terminate(); } catch (e) {}
      res.status(504).json({ error: "timeout getting price" });
    }
  }, 8000);
});

// Proposal (live)
app.post("/api/proposal", (req, res) => {
  const { symbol, amount, contract_type, duration, duration_unit, currency } = req.body;
  const ws = createDerivSocket();
  let responded = false;

  ws.on("open", () => {
    ws.send(JSON.stringify({
      proposal: 1,
      amount,
      basis: "stake",
      contract_type,
      currency: currency || "USD",
      duration,
      duration_unit,
      symbol
    }));
  });

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.proposal && !responded) {
        responded = true;
        res.json({ success: true, proposal: data.proposal });
        ws.close();
      } else if (data.error && !responded) {
        responded = true;
        res.status(400).json({ error: data.error.message });
        ws.close();
      }
    } catch (err) {
      if (!responded) {
        responded = true;
        res.status(500).json({ error: "invalid response from websocket" });
      }
      ws.close();
    }
  });

  ws.on("error", () => {
    if (!responded) {
      responded = true;
      res.status(500).json({ error: "websocket error" });
    }
  });

  setTimeout(() => {
    if (!responded) {
      responded = true;
      try { ws.terminate(); } catch (e) {}
      res.status(504).json({ error: "timeout getting proposal" });
    }
  }, 8000);
});

// Buy (live) - requires DERIV_API_TOKEN in .env
app.post("/api/buy", (req, res) => {
  const { symbol, amount, contract_type, duration, duration_unit, currency } = req.body;

  if (!TOKEN) {
    return res.status(401).json({ error: "Server missing DERIV_API_TOKEN. Set it in .env before using live buy." });
  }

  const ws = createDerivSocket();
  let authorized = false;
  let responded = false;

  ws.on("open", () => {
    // authorize first
    ws.send(JSON.stringify({ authorize: TOKEN }));
  });

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);

      // Authorization success
      if (data.authorize && !authorized) {
        authorized = true;
        // Request a proposal after auth
        ws.send(JSON.stringify({
          proposal: 1,
          amount,
          basis: "stake",
          contract_type,
          currency: currency || "USD",
          duration,
          duration_unit,
          symbol
        }));
        return;
      }

      // Received proposal - proceed to buy using proposal id
      if (data.proposal && authorized && !responded) {
        // buy by proposal id
        ws.send(JSON.stringify({ buy: data.proposal.id }));
        return;
      }

      // Buy response
      if (data.buy && !responded) {
        responded = true;
        res.json({ success: true, buy: data.buy });
        ws.close();
        return;
      }

      // Handle error responses
      if (data.error && !responded) {
        responded = true;
        res.status(400).json({ error: data.error.message });
        ws.close();
        return;
      }
    } catch (err) {
      if (!responded) {
        responded = true;
        res.status(500).json({ error: "invalid response from websocket" });
      }
      ws.close();
    }
  });

  ws.on("error", (err) => {
    if (!responded) {
      responded = true;
      res.status(500).json({ error: "websocket error" });
    }
  });

  setTimeout(() => {
    if (!responded) {
      responded = true;
      try { ws.terminate(); } catch (e) {}
      res.status(504).json({ error: "timeout during buy" });
    }
  }, 20000); // allow more time for auth + buy
});

app.listen(PORT, () => console.log(`🚀 Live Deriv trading API running on port ${PORT}`));
