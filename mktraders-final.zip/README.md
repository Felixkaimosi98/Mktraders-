# MKTraders - Render-ready full stack (Live + Demo)

Deploy instructions are in the README. Set DERIV_API_TOKEN in Render environment variables.
