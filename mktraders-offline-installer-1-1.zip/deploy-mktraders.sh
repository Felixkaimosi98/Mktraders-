#!/usr/bin/env bash
set -euo pipefail
OWNER="felixkaimosi"
REPO="mktraders"
AWS_REGION="af-south-1"
DOMAIN="mktraders.com"
DERIV_APP_ID="105977"
for cmd in gh git terraform; do if ! command -v $cmd >/dev/null 2>&1; then echo "Please install $cmd"; exit 1; fi; done
echo "Auto installer placeholder"
