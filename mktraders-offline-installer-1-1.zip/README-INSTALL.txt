MKTraders offline installer (auto). Run deploy-mktraders.sh after extracting.
