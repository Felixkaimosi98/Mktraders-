import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const nav = useNavigate()

  const login = async ()=>{
    try{
      const res = await axios.post('/auth/login', { email, password });
      localStorage.setItem('token', res.data.token);
      nav('/dashboard');
    }catch(e){
      alert('Login failed');
    }
  }

  const register = async ()=>{
    try{
      const res = await axios.post('/auth/register', { email, password });
      localStorage.setItem('token', res.data.token);
      nav('/dashboard');
    }catch(e){
      alert('Register failed');
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Login / Register</h2>
      <div>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
      </div>
      <div>
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      </div>
      <div style={{ marginTop: 8 }}>
        <button onClick={login}>Login</button>
        <button onClick={register} style={{ marginLeft: 8 }}>Register</button>
      </div>
    </div>
  )
}
