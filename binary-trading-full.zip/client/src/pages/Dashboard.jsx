import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { io } from 'socket.io-client'
import TradeWidget from '../components/TradeWidget'

export default function Dashboard(){
  const [user, setUser] = useState(null)
  const socket = io();

  useEffect(()=>{
    const token = localStorage.getItem('token');
    if(!token) return;
    axios.get('/api/me', { headers: { Authorization: 'Bearer ' + token } }).then(r=> setUser(r.data.user)).catch(()=>{});
  },[])

  if(!user) return <div>Please login</div>

  return (
    <div style={{ padding: 20 }}>
      <h2>Welcome, {user.email}</h2>
      <TradeWidget asset="R_100" socket={socket} />
    </div>
  )
}
