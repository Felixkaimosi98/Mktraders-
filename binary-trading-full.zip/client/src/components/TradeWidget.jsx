import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function TradeWidget({ asset, socket }){
  const [price, setPrice] = useState(null)
  const [stake, setStake] = useState(1)
  const [duration, setDuration] = useState(60)
  const [status, setStatus] = useState('')

  useEffect(()=>{
    if(!socket) return;
    socket.emit('subscribe_price', { symbol: asset });
    socket.on('price', (p) => {
      if(p.symbol === asset) setPrice(p.quote);
    });
    return ()=>{
      socket.emit('unsubscribe_price', { symbol: asset });
      socket.off('price');
    }
  },[asset, socket])

  const place = async (direction) =>{
    const token = localStorage.getItem('token');
    try{
      const res = await axios.post('/api/place-trade', { asset, direction, stake, duration }, { headers: { Authorization: 'Bearer ' + token } });
      if(res.data.ok) setStatus('Trade placed');
    }catch(e){ setStatus('Error'); }
  }

  return (
    <div style={{ border: '1px solid #ddd', padding: 12, width: 420 }}>
      <div><strong>{asset}</strong></div>
      <div>Price: {price ?? '—'}</div>
      <div style={{ marginTop: 8 }}>
        <input type="number" value={stake} onChange={e=>setStake(Number(e.target.value))} />
        <input type="number" value={duration} onChange={e=>setDuration(Number(e.target.value))} style={{ marginLeft: 8 }} />
      </div>
      <div style={{ marginTop: 8 }}>
        <button onClick={()=>place('CALL')}>Call</button>
        <button onClick={()=>place('PUT')} style={{ marginLeft: 8 }}>Put</button>
      </div>
      <div style={{ marginTop: 8 }}>Status: {status}</div>
    </div>
  )
}
