import express from 'express';
import prisma from '../db.js';
import { authMiddleware } from '../auth.js';
import bc from '../index.js';

const router = express.Router();

router.get('/me', authMiddleware, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id } });
  res.json({ user: { id: user.id, email: user.email, name: user.name, kycDone: user.kycDone } });
});

router.post('/kyc', authMiddleware, async (req, res) => {
  // stub: mark kyc done — replace with real provider integration
  await prisma.user.update({ where: { id: req.user.id }, data: { kycDone: true } });
  res.json({ ok: true });
});

router.get('/trades', authMiddleware, async (req, res) => {
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' } });
  res.json({ trades });
});

router.post('/place-trade', authMiddleware, async (req, res) => {
  const { asset, direction, stake, duration } = req.body;
  if(!asset || !direction || !stake || !duration) return res.status(400).json({ error: 'Missing' });
  const trade = await prisma.trade.create({ data: { userId: req.user.id, asset, direction, stake: Number(stake), duration: Number(duration), result: 'PENDING' } });
  try{
    const payload = {
      buy: stake,
      price: stake,
      parameters: { asset, direction, duration }
    };
    bc.placeContract(payload);
  }catch(e){
    console.error('broker error', e);
  }
  res.json({ ok: true, trade });
});

export default router;
