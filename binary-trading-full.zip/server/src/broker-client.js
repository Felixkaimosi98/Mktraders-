import WebSocket from 'ws';
import EventEmitter from 'events';

class BrokerClient extends EventEmitter {
  constructor(wsUrl, apiToken){
    super();
    this.wsUrl = wsUrl;
    this.apiToken = apiToken;
    this.ws = null;
  }

  connect(){
    this.ws = new WebSocket(this.wsUrl);
    this.ws.on('open', () => {
      console.log('Connected to broker WS');
      if(this.apiToken) this.ws.send(JSON.stringify({ authorize: this.apiToken }));
    });
    this.ws.on('message', (msg) => {
      try{
        const data = JSON.parse(msg.toString());
        // forward ticks / broadcasts
        this.emit('message', data);
      }catch(e){
        console.error('broker parse error', e);
      }
    });
    this.ws.on('error', (err) => this.emit('error', err));
    this.ws.on('close', () => {
      this.emit('close');
      // reconnect after delay
      setTimeout(()=> this.connect(), 3000);
    });
  }

  subscribeTicks(symbol){
    if(!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const req = { ticks: symbol, subscribe: 1 };
    this.ws.send(JSON.stringify(req));
  }

  placeContract(payload){
    if(!this.ws || this.ws.readyState !== WebSocket.OPEN) throw new Error('broker disconnected');
    this.ws.send(JSON.stringify(payload));
  }
}

export default BrokerClient;
