import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import dotenv from 'dotenv';
import authRouter from './routes/auth.js';
import apiRouter from './routes/api.js';
import BrokerClient from './broker-client.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.use('/auth', authRouter);
app.use('/api', apiRouter);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// start broker client
const broker = new BrokerClient(process.env.BROKER_WS_URL, process.env.BROKER_API_TOKEN);
broker.connect();

// when broker sends messages, forward ticks to clients
broker.on('message', (m) => {
  if(m && m.tick && m.echo_req && m.echo_req.ticks){
    const symbol = m.echo_req.ticks;
    io.to(`price_${symbol}`).emit('price', { symbol, quote: m.tick.quote, epoch: m.tick.epoch });
  }
});

io.on('connection', (socket) => {
  console.log('client connected', socket.id);
  socket.on('subscribe_price', ({ symbol }) => {
    socket.join(`price_${symbol}`);
    broker.subscribeTicks(symbol);
  });
  socket.on('unsubscribe_price', ({ symbol }) => {
    socket.leave(`price_${symbol}`);
  });
  socket.on('disconnect', () => {});
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, ()=> console.log('Server listening', PORT));

export default broker;
