import express from "express";
import WebSocket from "ws";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());

const PORT = process.env.PORT || 4000;
const APP_ID = process.env.DERIV_APP_ID || "1089"; // replace with your app id

// Simple price endpoint - returns one tick then closes
app.get("/api/price/:symbol", async (req, res) => {
  const symbol = req.params.symbol;
  const ws = new WebSocket(`wss://ws.binaryws.com/websockets/v3?app_id=${APP_ID}`);

  let responded = false;
  ws.on("open", () => {
    ws.send(JSON.stringify({ ticks: symbol }));
  });

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.tick && !responded) {
        responded = true;
        res.json({ symbol, price: data.tick.quote });
        ws.close();
      }
    } catch (err) {
      if (!responded) {
        responded = true;
        res.status(500).json({ error: "invalid response from websocket" });
      }
      ws.close();
    }
  });

  ws.on("error", (err) => {
    if (!responded) {
      responded = true;
      res.status(500).json({ error: "websocket error" });
    }
  });

  // safety timeout
  setTimeout(() => {
    if (!responded) {
      responded = true;
      try { ws.terminate(); } catch(e){}
      res.status(504).json({ error: "timeout getting price" });
    }
  }, 8000);
});

app.listen(PORT, () => console.log(`✅ Backend running on port ${PORT}`));
