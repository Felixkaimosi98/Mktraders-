# Deriv Trading Site (Starter Template)

This is a minimal full-stack starter template for building a third-party site that connects to Deriv's WebSocket API.

## Structure
- `backend/` - Node.js Express server that queries Deriv's WebSocket for a single tick price.
- `frontend/` - Vite + React minimal app that shows price and demo trade buttons.

## Quick start

### Backend
1. `cd backend`
2. Copy `.env.example` to `.env` and set `DERIV_APP_ID` (use your app id; 1089 is test).
3. `npm install`
4. `npm start`
Backend will run at `http://localhost:4000`.

### Frontend
1. `cd frontend`
2. `npm install`
3. `npm run dev`
Frontend will open at `http://localhost:5173` (Vite default).

## Notes
- This template is intentionally minimal. Add authentication, secure token storage, proper error handling, real trading endpoints (`buy`), KYC, and compliance before using with real funds.
- Replace the small demo UI with a production-ready design and charts (TradingView, lightweight charts, or Recharts).
