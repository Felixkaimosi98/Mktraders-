import { useEffect, useState } from "react";
import axios from "axios";

function Header() {
  return (
    <div className="card header">
      <h1>Deriv Binary Trading</h1>
      <button className="btn">Login with Deriv</button>
    </div>
  );
}

function PriceDisplay({ symbol, price }) {
  return (
    <div className="card" style={{ marginTop:16, textAlign:"center" }}>
      <div>{symbol}</div>
      <div className="price">{price ?? "Loading..."}</div>
    </div>
  );
}

function TradePanel() {
  const place = (side) => alert(`Demo: ${side} clicked (implement buy API call)`);
  return (
    <div className="card" style={{ marginTop:16 }}>
      <h3>Trade Controls</h3>
      <div className="controls">
        <button className="btn btn-buy" onClick={() => place("Buy ↑")}>Buy ↑</button>
        <button className="btn btn-sell" onClick={() => place("Sell ↓")}>Sell ↓</button>
      </div>
    </div>
  );
}

export default function App(){
  const [price, setPrice] = useState(null);
  const symbol = "R_50";

  useEffect(() => {
    const fetchPrice = async () => {
      try {
        const res = await axios.get(`http://localhost:4000/api/price/${symbol}`);
        setPrice(res.data.price);
      } catch (err) {
        console.error(err);
      }
    };
    fetchPrice();
    const id = setInterval(fetchPrice, 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="container">
      <Header />
      <PriceDisplay symbol={symbol} price={price} />
      <TradePanel />
    </div>
  );
}
